<link rel="stylesheet" href="{{ asset('vendors/core/core.css') }}">
<!-- endinject -->
<!-- plugin css for this page -->
<link rel="stylesheet" href="{{ asset('vendors/bootstrap-datepicker/bootstrap-datepicker.min.css') }}">
<!-- end plugin css for this page -->
<!-- inject:css -->
<link rel="stylesheet" href="{{ asset('fonts/feather-font/css/iconfont.css') }}">
<link rel="stylesheet" href="{{ asset('vendors/flag-icon-css/css/flag-icon.min.css') }}">
<!-- endinject -->
{{-- DataTables --}}
{{-- <link rel="stylesheet" type="text/css"
    href="https://cdn.datatables.net/v/dt/dt-1.10.21/b-1.6.3/b-colvis-1.6.3/b-html5-1.6.3/datatables.min.css" /> --}}
<!-- Layout styles -->
<link rel="stylesheet" href="{{ asset('css/demo_1/style.css') }}">
<!-- End layout styles -->
{{--<link rel="shortcut icon" href="{{ asset('images/favicon.png') }}" />--}}



    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.24/css/jquery.dataTables.min.css">
@yield('styles')
