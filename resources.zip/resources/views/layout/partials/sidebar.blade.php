<style>
   .sidebar .sidebar-header{
   width: 320px ;
   }
   .sidebar{
   width: 320px ;
   }
   .page-content{
   padding: 25px 25px 25px 101px !important;
   }
</style>
<nav class="sidebar">
   <div class="sidebar-header">
      <a href="/home" class="sidebar-brand" style="font-size:18px">
      Cryto<span> Fighter</span>
      </a>
      <div class="sidebar-toggler not-active">
         <span></span>
         <span></span>
         <span></span>
      </div>
   </div>
   <div class="sidebar-body">
      <ul class="nav">
         
         
         <li class="nav-item">
                     <a href="/home" class="nav-link ">All Coins</a>
                  </li>
                  <li class="nav-item">
                     <a href="/change-password" class="nav-link "> Change Password</a>
                  </li>
      </ul>
   </div>
</nav>